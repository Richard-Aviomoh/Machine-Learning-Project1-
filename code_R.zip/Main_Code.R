
#Install Packages..............................................................

install.packages("caret")
install.packages("dplyr")
install.packages("tidyverse")
install.packages("plotrix")
install.packages("tidyr")
install.packages("magrittr")
install.packages("corrplot")




#Load Libraries.................................................................
library('caret')
library(dbplyr)
library(tidyr)
library(tidyverse)
library(tidyr)
library(magrittr)
library(plyr)
library(corrplot)
library(ggplot2)
library(reshape2)
library(dplyr)
library(plotrix)


#Reading Data...................................................................

Levels_Fyi_Salary_Data <- read.csv("U:/ICA/Levels_Fyi_Salary_Data.csv")
View(Levels_Fyi_Salary_Data)
Salary_Data <- Levels_Fyi_Salary_Data


#Table Details..................................................................

dim(Salary_Data)                 
head(Salary_Data, n=20)
tail(Salary_Data, n=20)
str(Salary_Data) 
summary(Salary_Data)

# Checking for missing values
miss <- colSums(is.na(Salary_Data))/nrow(Salary_Data)
round(miss, 2)

# Checking for duplicates
sum(duplicated(Salary_Data))

#Checking the length of unique values...........................................

length(unique(Salary_Data$tag)) #Only accepts one argument
length(unique(Salary_Data$gender))
length(unique(Salary_Data$Education))
length(unique(Salary_Data$Race))
length(unique(Salary_Data$level))

#Deleting irrelevant columns....................................................

Salary_Data_update <- Salary_Data[,-14:-28 ]
View(Salary_Data_update)

#Deleting rows using filtering..................................................

Final_Data<- filter(Salary_Data_update,tag != "NA",level != "NA",basesalary != "0")


#Replacing missing values and further filtering.................................

Final_Data$gender[which(is.na(Final_Data$gender))] <- "Male"
Final_Data<- filter(Final_Data,gender == "Male" |gender == "Female" |gender == "Other")

Final_Data$Education[which(is.na(Final_Data$Education))] <- "Master's Degree"
view(Final_Data)


#changing numerical variable to character variable............................


Final_Data$experience <- cut(Final_Data$yearsofexperience, 
                             breaks = c(-1,2,5,70),
                             labels = c("Inexperienced","Intermediate", "experienced"))

Final_Data$Term <- cut(Final_Data$yearsatcompany, 
                       breaks = c(-1,3,70),
                       labels = c("Short_term","Long_term"))

#Creating New Columns for Machine Learning later on.........................................................

Gender_factor <- factor(Final_Data$gender, levels=c("Male","Female","Other"), labels=c(0,1,2))
Education_Factor <- factor(Final_Data$Education, levels=c("Master's Degree","PhD",
                                                          "Bachelor's Degree","Some College","Highschool" ), labels=c(0,1,2,3,4))

Final_Data$Gender_factor <- Gender_factor


Final_Data$Education_Factor <- Education_Factor



#Data_Visualization.............................................................

#Count of Education
ggplot(Address, aes(x = Education, fill = gender)) +
  geom_bar(position = "dodge")+
  ggtitle("Count for Qualifications")



#Total-yearly-compensation by title and gender
ggplot(Final_Data, aes(y =title , x = totalyearlycompensation)) +
  geom_bar(stat = "summary", fun = "mean")+
  ggtitle("Average Total-Yearly-Compensation For Each Job Title ")


ggplot(Final_Data, aes(x = gender, y = totalyearlycompensation,reorder(gender, -totalyearlycompensation), fill=gender)) +
  geom_bar(stat = "summary", fun = "mean")+
  ggtitle("Average Total-Yearly-Compensation By Gender ")

ggplot(Company, aes(y = company, x = totalyearlycompensation, reorder(company, -totalyearlycompensation))) +
  geom_bar(stat = "summary", fun = "mean")+
  ggtitle("Average Total-Yearly-Compensation By Companies With Most Counts ")


#BOX_PLOTS

#Education vs total-yearly-compensation 
ggplot(Final_Data, aes(y =Education , x = totalyearlycompensation, fill=Education)) +
  geom_boxplot() +
  stat_summary (fun = "mean", geom = "point", shape = 8, size = 2, color = "white")+
  ggtitle("BoxPlot Showing Total-Yearly-Compensation By Education")

#Gender vs total-yearly-compensation
ggplot(Final_Data, aes(y =gender , x = totalyearlycompensation, fill=gender)) +
  geom_boxplot() +
  stat_summary (fun = "mean", geom = "point", shape = 8, size = 2, color = "white")+
  ggtitle("BoxPlot Showing Total-Yearly-Compensation By Gender")

#Removing out-liners from box_plots.............................................

ggplot(Final_Data, aes(y =Education , x = totalyearlycompensation, fill=Education)) +
  geom_boxplot(outlier.shape = NA) +
  stat_summary (fun = "mean", geom = "point", shape = 8, size = 2, color = "white") +
  scale_x_continuous(limits = c(0,500000))+
  ggtitle("BoxPlot Showing Total-Yearly-Compensation By Education Without Outliers")


ggplot(Final_Data, aes(y =gender , x = totalyearlycompensation, fill=gender)) +
  geom_boxplot() +
  stat_summary (fun = "mean", geom = "point", shape = 8, size = 2, color = "white")+
  ggtitle("BoxPlot Showing Total-Yearly-Compensation By Gender") +
  scale_x_continuous(limits = c(0,500000))

#Bonus.......................................................................... 

ggplot(Final_Data, aes(y =bonus , x = Term, fill=Term)) +
  geom_bar(stat = "summary", fun = "mean")+
  ggtitle("Bar-Chart Showing Average Bonus By Time Spent in Company")

ggplot(Final_Data, aes(y =bonus , x = experience, fill=experience)) +
  geom_bar(stat = "summary", fun = "mean")+
  ggtitle("Bar-Chart Showing Average Bonus By Experience")

ggplot(Final_Data, aes(y =bonus , x = gender, fill=gender)) +
  geom_bar(stat = "summary", fun = "mean")+
  ggtitle("Bar-Chart Showing Average Bonus By Gender")


#stock-grant-value............................................................... 

ggplot(Final_Data, aes(y =stockgrantvalue , x = Term, fill=Term)) +
  geom_bar(stat = "summary", fun = "mean")+
  ggtitle("Bar-Chart Showing Average Stock-Grant-Value By Time Spent in Company")

ggplot(Final_Data, aes(y =stockgrantvalue , x = experience, fill=experience)) +
  geom_bar(stat = "summary", fun = "mean")+
  ggtitle("Bar-Chart Showing Average Stock-Grant-Value By Experience")

ggplot(Final_Data, aes(y =stockgrantvalue , x = gender, fill=gender)) +
  geom_bar(stat = "summary", fun = "mean")+
  ggtitle("Bar-Chart Showing Average Stock-Grant-Value By Gender")

ggplot(Final_Data, aes(y = title , x = stockgrantvalue)) +
  geom_bar(stat = "summary", fun = "mean")+
  ggtitle("Bar-Chart Showing Average Stock-Grant-Value By Job Title")


#Location.......................................................................

Address_count<- count(Final_Data$location)

Address <- Final_Data[,-7:-12][-3:-5]
Address<- filter(Address, location == "Seattle, WA" | location == "San Francisco, CA" |
                   location == "New York, NY" | location == "Redmond, WA"|
                   location == "Mountain View, CA" | location == "Sunnyvale, CA"|
                   location == "San Jose, CA" | location == "Austin, TX"|
                   location == "Menlo Park, CA" | location == "Cupertino, CA")

ggplot(Address, aes(y = location)) +
  geom_bar()+
  ggtitle("Top 10 Employee Locations With The Highest Counts")

ggplot(Address, aes(y = location, fill = gender)) +
  geom_bar(position = "dodge")+
  ggtitle("Top 10 Employee Locations With The Highest Counts")

#Company Visualizations.........................................................................
df<-count(Final_Data$company)
df %>% top_n(10)
df %>% top_n(-10)
Company <- Final_Data[,-1][-2:-3][-3:-9]

Company<- filter(Company, company == "Amazon" | company == "Apple" |
                   company == "Apple" | company == "Cisco"|
                   company == "Facebook" | company == "Google"|
                   company == "IBM" | company == "Intel"|
                   company == "Salesforce" | company == "Microsoft")


ggplot(Company, aes(y = company, fill = gender)) +
  geom_bar(position = "dodge")+
  ggtitle("Top 10 Companies With The Highest Counts")

#Base salary Visualizations....................................................................


ggplot(Final_Data, aes(y =basesalary , x = gender, fill=gender)) +
  geom_bar(stat = "summary", fun = "mean")+
  ggtitle("Bar-Chart Showing Average Base Salary By Gender")

ggplot(Final_Data, aes(y =basesalary , x = Education, fill=Education)) +
  geom_bar(stat = "summary", fun = "mean")+
  ggtitle("Bar-Chart Showing Average Base Salary By Education")

ggplot(Final_Data, aes(basesalary, x = value, color = variable)) +
  geom_point(aes(x =yearsatcompany, col = "yearsatcompany" )) +
  geom_point(aes(x =yearsofexperience, col = "yearsofexperience" ))+
  geom_smooth(aes(x =yearsatcompany),method = lm, col = "Orangered", size = 1)+
  geom_smooth(aes(x =yearsofexperience),method = lm, col = "light blue", size = 1)+
  theme_dark()+
  ggtitle("Rate of change of Base-Salary Overy Years-At-Company and Years-Of_Experience")


#Date conversion.................................................................
Date <- mutate(Final_Data, timestamp = as.Date(timestamp, format= "%m/%d/%Y"))
class(Date$timestamp)

Date1 <- filter(Date, title == "Software Engineering Manager")


ggplot(Date1, aes(y = totalyearlycompensation , x = timestamp)) +
  geom_point() + 
  geom_smooth(method = lm, col = "red", size = 1)+
  ggtitle("A Chart Showing Total-Yearly-Compensation Over Time For Software Engineering Manager")



#Pie chart for gender...........................................................



Male<- filter(Final_Data, gender == "Male")
Male<-count(Male$gender)

Female<- filter(Final_Data, gender == "Female")
Female<-count(Female$gender)

Other<- filter(Final_Data, gender == "Other")
Other<-count(Other$gender)

V1<- c(Male1,Female1,Other1)

C_gender <- c(34614, 6812, 373)

Gender_pie<- c("Male", "Female", "Other")
Percentage <- round(C_gender/sum(C_gender)*100)
lbl <- paste(Gender_pie, Percentage)
lbl<- paste(lbl, "%", sep = "")

pie(C_gender, labels = lbl, col = c("light blue","light green","pink"),
    main = "Count of Gender") 





#Pie chart for Education...........................................................

Masters<- filter(Final_Data, Education == "Master's Degree")
Masters<-count(Masters$Education)

PhD<- filter(Final_Data, Education == "PhD")
PhD<-count(PhD$Education)

Bachelor<- filter(Final_Data, Education == "Bachelor's Degree")
Bachelor<-count(Bachelor$Education)

Some_College<- filter(Final_Data, Education == "Some College")
Some_College<-count(Some_College$Education)

Highschool<- filter(Final_Data, Education == "Highschool")
Highschool<-count(Highschool$Education)

Education_c <- c(Masters,Some_College,Bachelor,PhD,Highschool)
view(Education_c)

Education_c <- c(15372,355,12595,1701,320)
view(Education_c)



Education_pie<- c("Masters", "Some_College", "Bachelor", "PhD","Highschool")
Percentage2 <- round(Education_c/sum(Education_c)*100)
lbl2 <- paste(Education_pie, Percentage2)
lbl2<- paste(lbl2, "%", sep = "")

pie(Education_c, labels = lbl2, col = c("light blue","light green","pink","cyan","yellow"),
    main = "Count of Education")



#Density plots...................................................................

den <- density(Final_Data$basesalary)
plot(den, frame = FALSE, col = "blue", main = "Density Plot")

hist(Final_Data$basesalary, prob = TRUE, border = "black", col = "light blue",
     xlab = "Base Salary", main = "Density Plot For Base-Salary") 
lines(density(Final_Data$basesalary), lwd = 2, col = "Chocolate3")

hist(Final_Data$totalyearlycompensation, prob = TRUE, border = "black", col = "light blue",
     xlab = "totalyearlycompensation", main = "Density Plot For Total-Yearly-Compensation") 
lines(density(Final_Data$totalyearlycompensation), lwd = 2, col = "Chocolate3")

hist(Final_Data$bonus, prob = TRUE, border = "black", col = "light blue",
     xlab = "bonus", main = "Density Plot For Bonus") 
lines(density(Final_Data$bonus), lwd = 2, col = "Chocolate3")

hist(Final_Data$stockgrantvalue, prob = TRUE, border = "black", col = "light blue",
     xlab = "stockgrantvalue", main = "Density Plot For Stock-Grant-Value") 
lines(density(Final_Data$stockgrantvalue), lwd = 2, col = "Chocolate3")

hist(Final_Data$yearsofexperience, prob = TRUE, border = "black", col = "light blue",
     xlab = "yearsofexperience", main = "Density Plot For Years-of-Experience") 
lines(density(Final_Data$yearsofexperience), lwd = 2, col = "Chocolate3")

hist(Final_Data$yearsatcompany, prob = TRUE, border = "black", col = "light blue",
     xlab = "yearsatcompany", main = "Density Plot For Years-at-Company") 
lines(density(Final_Data$yearsatcompany), lwd = 2, col = "Chocolate3")




#MACHINE LEARNING............................................................................................................


#Correlation and scatter_plot.................................................................................................

Ml_table <- filter(Final_Data, company == "Amazon")
Ml_table[["Gender_factor"]] = as.integer(Ml_table[["Gender_factor"]])
Ml_table[["Education_Factor"]] = as.integer(Ml_table[["Education_Factor"]])

correlation_table <- Ml_table[,-1:-4][,-2][,-4][-7:-8][-7:-8]
str(correlation_table)

correlations <- cor(correlation_table)
corrplot(correlations, method="number")
corrplot(correlations, method="circle")


pairs(correlation_table)


#Checking Data Before Machine Learning...............................................................................................................

ML_Data <- correlation_table[,-4]
ML_Data <- correlation_table
dim(ML_Data)
str(ML_Data)
summary(ML_Data)
anyNA(ML_Data)
miss <- colSums(is.na(ML_Data))/nrow(ML_Data)
round(miss, 2)


#Creating Train and Testing Data_sets...................................................................................................
#Ml_table <- filter(Ml_table, Gender_factor == "1"| Gender_factor == "0")
intrain1 <- createDataPartition(y = ML_Data$Gender_factor, p= 0.7, list = FALSE)
training1 <- ML_Data[intrain1,]
testing1 <- ML_Data[-intrain1,]

training1[["Gender_factor"]] = factor(training1[["Gender_factor"]])

trctrl <- trainControl(method = "repeatedcv", number = 10, repeats = 3)

install.packages("e1071")
library("e1071")


svm_Linear <- train(Gender_factor ~., data = training1, method = "svmLinear",
                    trControl=trctrl,preProcess = c("center", "scale"),tuneLength = 10)
svm_Linear

test_pred2 <- predict(svm_Linear, newdata = testing1)
test_pred2

confusionMatrix(table(test_pred2, testing1$Gender_factor))



#optimization................................................................................................

grid <- expand.grid(C = c(0,0.01, 0.05, 0.1, 0.25, 0.5, 0.75, 1, 1.25, 1.5
                          , 1.75, 2,5))

grid2 <- expand.grid(C = c(0,10,20,30))


svm_Linear_Grid <- train(Gender_factor ~., data = training1, method = "svmLinear",
                         trControl=trctrl,preProcess = c("center", "scale"),tuneGrid = grid,tuneLength= 10)
svm_Linear_Grid

test_pred_grid <- predict(svm_Linear_Grid, newdata = testing1)

test_pred_grid

confusionMatrix(table(test_pred_grid, testing1$Gender_factor))

plot(svm_Linear_Grid)



